# -*- coding: utf-8 -*-
#import time,serial,smtplib
import sys 
from PyQt5 import QtGui, uic #,QtCore
import time,serial,smtplib
# Cargar nuestro archivo .ui
form_class = uic.loadUiType("alarma.ui")[0]

USUARIO_GMAIL = 'pdaarduino@gmail.com'
CONTRASENA_GMAIL = 'ardufcyt'
#DESTINATARIO = 'mail'
#print (DESTINATARIO)
REMITENTE = 'pdaarduino@gmail.com'
ASUNTO  = ' Hay un intruso en su hogar.  '
MENSAJE = ' Su sensor de seguridad ha detectado movimiento en su casa a las ' + time.strftime("%H:%M:%S")
arduino = serial.Serial('COM8', 9600, timeout = 3.0)    #El puerto se abre inmediatamente en la creación de objetos, cuando se da un puerto.

class MyWindowClass(QtGui.QMainWindow, form_class):
   
   def __init__(self, parent=None):
        QtGui.QMainWindow.__init__(self, parent)
        self.setupUi(self)
        self.btnactivar.clicked.connect(self.btnactivar_clicked)
        #self.boton.clicked.connect(self.btn_FtoC_clicked)

                     #Cerramos la conexión con el SMTP server de Google
    
     

   def btnactivar_clicked(self):
        mail = self.txtmail.text()
        print (mail)
        print(type(mail))
        DESTINATARIO = mail
        print (DESTINATARIO)

          
    #for destino in DESTINATARIO:
       # print("Envíando e-mail")
        #smtpserver = smtplib.SMTP("smtp.gmail.com",587)     #Definimos el objeto 'smtpserver' con smptlib.SMTP, SMTP("",) Administra la conexión SMTP
        #smtpserver.ehlo()                                   #Este método prepara envíar un correo electrónico
        #smtpserver.starttls()                               #Pone la conexión con el servidor SMTP en el modo de TLS.
        #smtpserver.ehlo()
        #smtpserver.login(USUARIO_GMAIL, CONTRASENA_GMAIL)   #Iniciamos sesion en el SMTP server de Google
        #header  = 'To:      ' + DESTINATARIO + '\n'         #Construimos el 'HEADER' para envíar el correo electrónico       
        #header += 'From:    ' + REMITENTE    + '\n'
        #header += 'Subject: ' + ASUNTO       + '\n'
        #print (header)
        #msg = header + '\n' + MENSAJE + ' \n\n'             #Concatenamos el'HEADER' y el 'MENSAJE' del correo electrónico
        #smtpserver.sendmail(REMITENTE, DESTINATARIO, msg)   #Envíamos el correo electrónico
        #smtpserver.close()                                  #Cerramos la conexión con el SMTP server de Google
        
        while True:
            lineaLeida = arduino.readline() 
            #print(lineaLeida)
            # print(lineaLeida)
            
            señal = lineaLeida.decode('ascii')
            
            print (señal)
             
            if señal[0] == "1" :
                #enviar_correo_electronico()                     #Envío un correo electrónico 
                print("salio del metodo")
                print("Envíando e-mail")
                smtpserver = smtplib.SMTP("smtp.gmail.com",587)     #Definimos el objeto 'smtpserver' con smptlib.SMTP, SMTP("",) Administra la conexión SMTP
                smtpserver.ehlo()                                   #Este método prepara envíar un correo electrónico
                smtpserver.starttls()                               #Pone la conexión con el servidor SMTP en el modo de TLS.
                smtpserver.ehlo()
                smtpserver.login(USUARIO_GMAIL, CONTRASENA_GMAIL)   #Iniciamos sesion en el SMTP server de Google
                header  = 'To:      ' + DESTINATARIO + '\n'         #Construimos el 'HEADER' para envíar el correo electrónico       
                header += 'From:    ' + REMITENTE    + '\n'
                header += 'Subject: ' + ASUNTO       + '\n'
                print (header)
                msg = header + '\n' + MENSAJE + ' \n\n'             #Concatenamos el'HEADER' y el 'MENSAJE' del correo electrónico
                smtpserver.sendmail(REMITENTE, DESTINATARIO, msg)   #Envíamos el correo electrónico
                smtpserver.close()                                  #Cerramos la conexión con el SMTP server de Google
                
        time.sleep(0.5) 

 
app = QtGui.QApplication(sys.argv)
MyWindow = MyWindowClass(None)
MyWindow.show()
app.exec_()



 


