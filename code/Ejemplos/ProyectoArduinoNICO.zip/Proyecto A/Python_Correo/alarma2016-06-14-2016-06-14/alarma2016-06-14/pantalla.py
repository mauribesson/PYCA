# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\mag\Dropbox\PythonQt5\alarma\MainWindow.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

import arduino_smtp

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(632, 440)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(160, 30, 251, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(50, 130, 531, 51))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.txtmail = QtWidgets.QLineEdit(self.centralwidget)
        self.txtmail.setGeometry(QtCore.QRect(50, 170, 441, 20))
        self.txtmail.setObjectName("txtmail")
        self.btnaceptar = QtWidgets.QPushButton(self.centralwidget)
        self.btnaceptar.setGeometry(QtCore.QRect(410, 220, 81, 23))
        self.btnaceptar.setObjectName("btnaceptar")
        self.btncancelar = QtWidgets.QPushButton(self.centralwidget)
        self.btncancelar.setGeometry(QtCore.QRect(520, 220, 81, 23))
        self.btncancelar.setObjectName("btncancelar")
        self.btnactivar = QtWidgets.QPushButton(self.centralwidget)
        self.btnactivar.setGeometry(QtCore.QRect(50, 310, 91, 23))
        self.btnactivar.setObjectName("btnactivar")
        self.btnapagar = QtWidgets.QPushButton(self.centralwidget)
        self.btnapagar.setGeometry(QtCore.QRect(420, 310, 75, 23))
        self.btnapagar.setObjectName("btnapagar")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(210, 80, 151, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.txtcant = QtWidgets.QLineEdit(self.centralwidget)
        self.txtcant.setGeometry(QtCore.QRect(320, 220, 51, 16))
        self.txtcant.setObjectName("txtcant")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(50, 200, 251, 51))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label_4.setFont(font)
        self.label_4.setObjectName("label_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 632, 21))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Sistema de Alarmas"))
        self.label_2.setText(_translate("MainWindow", "Ingrese e-mail/s separados por punto coma (;) al cual mandaremos el aviso:"))
        self.btnaceptar.setText(_translate("MainWindow", "Aceptar datos"))
        self.btncancelar.setText(_translate("MainWindow", "Cancelar"))
        self.btnactivar.setText(_translate("MainWindow", "Activar Alarma"))
        self.btnapagar.setText(_translate("MainWindow", "Apagar"))
        self.label_3.setText(_translate("MainWindow", "ALARM@IL"))
        self.label_4.setText(_translate("MainWindow", "Ingrese cantidad máxima de mail a recibir:"))
        self.btnaceptar.clicked.connect(self.pushbtnaceptar_click)
        #self.btncancelar.clicked.connect(self.pushbtncancelar_click)
        self.btnactivar.clicked.connect(self.pushbtnactivar_click)

        
    def pushbtnaceptar_click(self):
        arduino_smtp.DESTINATARIO = self.txtmail.text()
        print (self.txtmail.text())
        arduino_smtp.CANTIDAD = self.txtcant.text()
        print (self.txtcant.text())
    
    def pushbtnactivar_click(self):
                #arduino_smtp.CERRAR = 0
        arduino_smtp.bucleMail('0')
        #Ui_MainWindow.cerrar == 0
        #Ui_MainWindow.cerrar=0
        #print(cerrar)
       #arduino_smtp.pararBucle
       # arduino_smtp.CERRAR = 0
        #arduino_smtp.cerrar =0
        #print (self.lineEdit.text())
        print ('Bucle Apagado')
        
        
        
"""    
    def pushbtncancelar_click(self):
        #arduino_smtp.cerrar =='1'
        #cerrar = self.lineEdit.text()
        #cerrar=int(cerrar)
        #print(cerrar)
        #arduino_smtp.CANTIDAD = self.lineEdit.text()
        #arduino_smtp.CANTIDAD = self.lineEdit.text()        
        arduino_smtp.bucleMail()
        #Ui_MainWindow.cerrar=1
        #print ('Bucle Iniciado')
"""        
     