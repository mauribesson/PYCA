# -*- encoding: utf-8 -*-

import serial
import time
import smtplib

CANTIDAD=''

USUARIO_GMAIL = 'pdaarduino@gmail.com'
CONTRASENA_GMAIL = 'ardufcyt'
DESTINATARIO = ''
REMITENTE = 'pdaarduino@gmail.com'
ASUNTO  = ' Hay un intruso en su hogar.  '
MENSAJE = ' Su sensor de seguridad ha detectado movimiento en su casa a las ' + time.strftime("%H:%M:%S")
arduino = serial.Serial('COM8', 9600, timeout = 3.0)    #El puerto se abre inmediatamente en la creación de objetos, cuando se da un puerto.


def enviar_correo_electronico():
    print("Envíando e-mail")
    smtpserver = smtplib.SMTP("smtp.gmail.com",587)     #Definimos el objeto 'smtpserver' con smptlib.SMTP, SMTP("",) Administra la conexión SMTP
    smtpserver.ehlo()                                   #Este método prepara envíar un correo electrónico
    smtpserver.starttls()                               #Pone la conexión con el servidor SMTP en el modo de TLS.
    smtpserver.ehlo()
    smtpserver.login(USUARIO_GMAIL, CONTRASENA_GMAIL)   #Iniciamos sesion en el SMTP server de Google
    header  = 'To:      ' + DESTINATARIO + '\n'         #Construimos el 'HEADER' para envíar el correo electrónico       
    header += 'From:    ' + REMITENTE    + '\n'
    header += 'Subject: ' + ASUNTO       + '\n'
    print (header)
    msg = header + '\n' + MENSAJE + ' \n\n'             #Concatenamos el'HEADER' y el 'MENSAJE' del correo electrónico
    smtpserver.sendmail(REMITENTE, DESTINATARIO, msg)   #Envíamos el correo electrónico
    smtpserver.close()                                  #Cerramos la conexión con el SMTP server de Google
      

def bucleMail():
    print(CANTIDAD)
    cant=int(CANTIDAD)
    i=1
    while cant>=i:
        #print(i)
        #time.sleep(0.5)
        lineaLeida = arduino.readline()
        #print(lineaLeida)
        señal = lineaLeida.decode('ascii')
        print(señal)
        if señal [0] == "1":
            print(DESTINATARIO)
            enviar_correo_electronico()                     #Envío un correo electrónico 
            #print("salio del metodo")
            i=i+1  
        time.sleep(0.5)                                     #Suspende la ejecución por 0.5 segundos   
    print("ALARM@IL DESACTIVADA ENVIÓ EL MÁXIMO DE MAILS")
    print("VUELVA A ACTIVARLA")     
         
# EOF
