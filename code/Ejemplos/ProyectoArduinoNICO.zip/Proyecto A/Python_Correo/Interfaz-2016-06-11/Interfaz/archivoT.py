# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\amoyano\Desktop\Interfaz\MainWindow\MainWindow.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!

import arduino_smtp

from PyQt5 import QtCore, QtGui, QtWidgets
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(240, 30, 321, 51))
        font = QtGui.QFont()
        font.setPointSize(18)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(30, 160, 231, 51))
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(270, 180, 231, 16))
        self.lineEdit.setObjectName("lineEdit")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(520, 170, 75, 23))
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(520, 210, 75, 23))
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(160, 310, 75, 23))
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(410, 320, 75, 23))
        self.pushButton_4.setObjectName("pushButton_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 800, 20))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label.setText(_translate("MainWindow", "Sistema de Alarmas v1.0"))
        self.label_2.setText(_translate("MainWindow", "Ingrese Codigo electronico de destino:"))
        self.pushButton.setText(_translate("MainWindow", "Aceptar"))
        self.pushButton_2.setText(_translate("MainWindow", "Cancelar"))
        self.pushButton_3.setText(_translate("MainWindow", "Activar"))
        self.pushButton_4.setText(_translate("MainWindow", "Apagar"))
        self.pushButton.clicked.connect(self.pushButton_click)
        self.pushButton_3.clicked.connect(self.pushButton_3_click)

        
    def pushButton_click(self):
        arduino_smtp.DESTINATARIO = self.lineEdit.text()
        print (self.lineEdit.text())
    
#    def pushButton_2_click(self):
#
#    
    def pushButton_3_click(self):
        self.thread = WorkThread()
        self.thread.start()
        print ('Bucle Iniciado')
    
    def pushButton_4_click(self):
        self.thread.terminate()
        print ('Bucle Finalizado')

class WorkThread(QtCore.QThread):
    
    def __init__(self,distSlider,hombre):
        QtCore.QThread.__init__(self)
    
    def __del__(self):
        self.wait()
        
    def run(self):
        arduino_smtp.bucleMail()